HÀNH LANG KÝ ỨC – ĐẠI CHIẾN THÓI QUEN (V3)

CÁCH CHẠY:
1. Giải nén file ZIP.
2. Mở index.html bằng Chrome hoặc Edge.
3. Chọn "Bắt đầu / Chơi lại".

ĐIỀU KHIỂN:
A/D hoặc mũi tên trái/phải: di chuyển
SPACE: bắn
Q: lá chắn Lời Thầy Cô khi thanh năng lượng đầy
ENTER: tiếp tục hội thoại, chuyển màn, đọc thiệp
P: tạm dừng; R: chơi lại; M: bật/tắt âm thanh

GAMEPLAY:
- Ba boss: Trì Hoãn, Xao Nhãng, Tự Ti.
- Có 5 HP mỗi màn, vật phẩm hồi máu và nạp lá chắn.
- Hoàn thành từng màn nhận một mảnh thư.
- Thu đủ ba mảnh để ghép và đọc thiệp tri ân.

LƯU Ý: Game chạy offline, đồ họa pixel được vẽ bằng Canvas.
Tên trường được dùng trong nội dung tri ân, không phải sản phẩm chính thức của trường.
