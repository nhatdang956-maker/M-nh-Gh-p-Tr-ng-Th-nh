MẢNH GHÉP TRƯỞNG THÀNH - V3.2

Mở index.html bằng Chrome/Edge để chơi.
Giữ index.html, style.css và game.js cùng một thư mục.
Đưa cả 3 file lên thư mục gốc GitHub repository để triển khai GitHub Pages.

A/D hoặc mũi tên: di chuyển; Space: bắn; Q: lá chắn; Enter: tiếp tục; P: tạm dừng; R: chơi lại.

Công nghệ: HTML5, CSS3, JavaScript và Canvas 2D.
